﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Stumeet.Core.Entities
{
    public interface IEntity
    {

    }
}
